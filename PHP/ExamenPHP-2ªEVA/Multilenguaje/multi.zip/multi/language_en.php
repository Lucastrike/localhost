<?php
$texts = array(
	'Inicio' => 'Home',
	'Eventos' => 'Events',
	'Informacion' => 'Info',
	'Contacto' => 'Contact'
);
?>
